
# General:

### Q) If you had more time, what further improvements or new features would you add?
I would have definitely added more test coverage and used a conversion hook for the price. In order to speed up things I have committed the whole UI work together instead of breaking it in smaller PRs from feature branches as in the beginning.

### Q) Which parts are you most proud of? And why?
General Project Setup, I love some automation around quality and moving away from the developer experience the areas that once agreed are consistent.

### Q) Which parts did you spend the most time with? What did you find most difficult?
Making time for the test while selling/buying a house, the timing was particularly unfortunate as is very stressful and with my wife pregnant I was keen to shield her from it.

### Q) How did you find the test overall? Did you have any issues or have difficulties completing?If you have any suggestions on how we can improve the test, we'd love to hear them.
Good challenge, nothing to note on it.

