/// <reference types="react-scripts" />

declare module '*.scss';
declare module '*.svg';
declare module 'react-currency-conv';
