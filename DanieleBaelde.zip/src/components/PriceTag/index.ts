import PriceTag from './PriceTag';
export default PriceTag;
